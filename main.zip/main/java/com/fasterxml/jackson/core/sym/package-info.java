/**
 * Internal implementation classes for efficient handling of
 * of symbols in JSON (Object property names)
 */
package com.fasterxml.jackson.core.sym;

/**
 * Package for subtypes of {@link com.fasterxml.jackson.core.JacksonException}
 * defined and used by streaming API.
 */
package com.fasterxml.jackson.core.exc;

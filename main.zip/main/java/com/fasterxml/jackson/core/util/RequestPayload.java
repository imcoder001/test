package com.fasterxml.jackson.core.util;

import java.nio.charset.Charset;

import com.fasterxml.jackson.core.exc.StreamReadException;

/**
 * Container object used to contain optional information on content
 * being parsed, passed to {@link StreamReadException} in case of
 * exception being thrown; this may be useful for caller to display
 * information on failure.
 */
public class RequestPayload
    implements java.io.Serializable // just in case, even though likely included as transient
{
    private static final long serialVersionUID = 1L;

    // request payload as byte[]
    protected byte[] _payloadAsBytes;

    // request payload as String
    protected CharSequence _payloadAsText;

    // Charset if the request payload is set in bytes
    protected Charset _charset;

    public RequestPayload(byte[] bytes, Charset charset) {
        if (bytes == null) {
            throw new IllegalArgumentException();
        }
        _payloadAsBytes = bytes;
        _charset = charset;
    }

    public RequestPayload(CharSequence str) {
        if (str == null) {
            throw new IllegalArgumentException();
        }
        _payloadAsText = str;
    }

    /**
     * Returns the raw request payload object i.e, either byte[] or String
     * 
     * @return Object which is a raw request payload i.e, either byte[] or
     *         String
     */
    public Object getRawPayload() {
        if (_payloadAsBytes != null) {
            return _payloadAsBytes;
        }

        return _payloadAsText;
    }

    @Override
    public String toString() {
        if (_payloadAsBytes != null) {
            return new String(_payloadAsBytes, _charset);
        }
        return _payloadAsText.toString();
    }
}
